
import UU5 from "uu5g04";

export const ListContext = UU5.Common.Context.create();
export default ListContext;