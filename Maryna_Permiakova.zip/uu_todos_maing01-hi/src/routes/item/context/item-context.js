import UU5 from "uu5g04";

export const ItemContext = UU5.Common.Context.create();
export default ItemContext;